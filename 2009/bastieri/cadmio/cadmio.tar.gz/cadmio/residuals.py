#!/usr/bin/python
#coding=utf-8

from ROOT import TGraphErrors, TF1, TCanvas, TAxis
from array import array

class ResGraph:
    def __init__( self, graph, function ):
        self.name = graph.GetTitle() + ' res'
        self.residuals = array( 'd' )
        self.n = graph.GetN()
        self.func = function
        self.graph = TGraphErrors( graph )
        self.set_graph()
        self.set_style( graph )

    def set_graph( self ):
        l = list( range(self.n) )
        graph = self.graph
        for i, x, y in zip( l, graph.GetX(), graph.GetY() ):
            delta = y - self.func.Eval(x)
            self.residuals.append( delta )
        self.graph = TGraphErrors( graph.GetN(), graph.GetX(), self.residuals, graph.GetEX(), graph.GetEY() )

    def get_graph( self ):
        return self.graph

    graph = property(get_graph, set_graph)

    def set_style( self, g ):
        self.graph.SetName( self.name )
        self.graph.SetMarkerStyle(g.GetMarkerStyle())
        self.graph.SetMarkerColor(g.GetMarkerColor())
        self.graph.SetMarkerSize(g.GetMarkerSize())
        self.graph.SetLineColor(g.GetLineColor())
        self.graph.SetLineWidth(g.GetLineWidth())
        self.graph.GetYaxis().SetDecimals()
