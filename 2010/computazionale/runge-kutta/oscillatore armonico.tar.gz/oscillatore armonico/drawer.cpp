// =============================================== 
//       Filename:  drawer.cpp
// ===============================================

#include <cmath>
#include <iostream>
#include <sstream>
#include <fstream>
#include "TGraph.h"
#include "TF1.h"
#include "TAxis.h"
#include "TCanvas.h"
#include "TApplication.h"
#include "TStyle.h"

using namespace std;

int main(int argc, char **argv)
{
    cout << "usage:" << endl;
    cout << "t_max, dt, b, f0, omega" << endl;
    TApplication app("app", &argc, argv);
    gStyle->SetFillColor(0);

    double t_max, dt, b, f0, omega;
    string method;

    //set parameters and input file name (produced by solver.cpp)
    stringstream arguments;
    stringstream input_name;
    for (int i = 1; i < argc; i++){
        arguments << argv[i] << " ";
        input_name << argv[i] << "_";  //set output file name as arguments sequence
    }
    input_name << "eu_.out";
    cout << input_name.str() << endl;
    
    arguments >> t_max;
    arguments >> dt;
    arguments >> b;
    arguments >> f0;
    arguments >> omega;
    arguments >> method;
    
    double omega1 = sqrt(1.-b*b/4.);
    double A = f0/sqrt((1-omega)*(1-omega) + b*b*omega*omega);
    double delta = atan(b*omega / (1.-omega*omega));
    double esp = -b/2.;

    //draw graphs
    //F(t), x(t)
    TCanvas position_can("position_can", "Position");
    
    TF1 force("force", "[0] * cos([1] * x)", 0, t_max);
    force.SetParameters(f0, omega);
    force.SetLineColor(2); //red
    force.SetLineWidth(1);
    force.SetLineStyle(2);
    force.SetNpx(100000);
   
    TF1 analytical_pos("exact", "exp([0] * x) * cos([1] * x) + [2]*cos([3] * x + [4])", 0, t_max);
    analytical_pos.SetParameters(esp , omega1, A, omega, delta);
    //analytical_pos.SetLineColor(3); //green
    analytical_pos.SetLineWidth(0.1);
    analytical_pos.SetLineStyle(3);
    analytical_pos.SetNpx(100000);
    
    TGraph position_graph(input_name.str().c_str(), "%lg %lg %*lg %*lg %*lg");
    position_graph.SetTitle("Position");
    position_graph.SetMarkerSize(1.);
    position_graph.GetXaxis()->SetTitle("t");
    position_graph.GetXaxis()->SetRangeUser(0, t_max);
    position_graph.GetYaxis()->SetTitle("x");
    position_graph.GetYaxis()->SetDecimals();
    position_graph.Draw("AP");
//     analytical_pos.Draw("LSAME");
    position_can.SaveAs("position_graph.eps");
    if (f0) force.Draw("LSAME");

    //Delta E (t)
    TCanvas delta_energy_can("delta_energy_can", "Delta Energy");
    TGraph delta_energy_graph(input_name.str().c_str(), "%lg %*lg %lg %*lg %*lg");
    delta_energy_graph.SetTitle("E_{t} - E_{0}");
    delta_energy_graph.SetMarkerSize(0.5);
    delta_energy_graph.GetXaxis()->SetTitle("t");
    delta_energy_graph.GetXaxis()->SetRangeUser(0, t_max);
    delta_energy_graph.GetYaxis()->SetTitle("#Delta E");
    delta_energy_graph.GetYaxis()->SetDecimals();
    delta_energy_graph.Draw("AP");
    delta_energy_can.SaveAs("delta_energy_graph.eps");

    //average E (t)
    TCanvas energy_av_can("energy_av_can", "Average Energy");
    TGraph energy_av_graph(input_name.str().c_str(), "%lg %*lg %*lg %lg %*lg");
    energy_av_graph.SetTitle("Average energy per period");
    energy_av_graph.GetXaxis()->SetTitle("t");
    energy_av_graph.GetXaxis()->SetRangeUser(0, t_max);
    energy_av_graph.GetYaxis()->SetTitle("#bar{E}");
    energy_av_graph.GetYaxis()->SetDecimals();

    //average power (t)
    TCanvas power_av_can("power_av_can", "Average Power");
    TGraph power_av_graph(input_name.str().c_str(), "%lg %*lg %*lg %*lg %lg");
    power_av_graph.SetTitle("Average power transmitted per period");
    power_av_graph.GetXaxis()->SetTitle("t");
    power_av_graph.GetXaxis()->SetRangeUser(0, t_max);
    power_av_graph.GetYaxis()->SetTitle("#bar{P}");
    power_av_graph.GetYaxis()->SetDecimals();

    
    if (omega and f0){		//to be drawn only in case of external force
        energy_av_can.cd();
        energy_av_graph.Draw("AP");

        power_av_can.cd();
        power_av_graph.Draw("AP");
	
        power_av_can.SaveAs("power_av_graph.eps");
        energy_av_can.SaveAs("energy_av_graph.eps");
    }
    
    app.Run();
    return 0;
}
