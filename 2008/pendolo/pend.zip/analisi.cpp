//Analisi 1.0 -- Ilaria Brivio e Matteo Abis, 01/2008
//
//Analizza dati da file, restituendo tabella di frequenza,
//media aritmetica, errore quadratico medio ed errore sulla media.
#include<iostream>
#include<fstream>
#include<string>
#include<cmath>

using namespace std;

int contarighe(string);
double trovamax(double[], int );
double trovamin(double[], int );
double media(double[], int );
double sigma(double[], int );

int main()
	{
	string nomefile;
	cout << "Inserire il nome del file da analizzare: ";
	cin >> nomefile;
//copia dati sperimentali su array dinamico
	ifstream dati;
	dati.open(nomefile.c_str());
	while (!dati.is_open())
	{
		cout << "File non trovato!" << endl;
		cout << "Inserire il nome del file da analizzare: ";
		cin >> nomefile;
		dati.open(nomefile.c_str());
	}
	int osservazioni = contarighe(nomefile);
	if (osservazioni==1) //if per singolare e plurale
		cout << "\u00c8 stato trovato un solo dato." << endl;
	else cout << "Sono stati trovati " << osservazioni << " dati." << endl;
	double *tempi = new double[osservazioni];
	for(int i=0; i<osservazioni ; i++)
		dati >> tempi[i];
	dati.close();
	int n; //dimensione intervallini (ms)
	cout << "Inserire dimensione intervallini (ms): ";
	cin >> n;
	cin.get();
	double min, max;
	min = trovamin(tempi,osservazioni);
	max = trovamax(tempi,osservazioni);
	int m = int(((max-min)/n)+1); // calcola numero di intervallini presenti
	int *freq = new int[m];
	for(int i=0;i<m; i++) //inizializza a zero tutto l'array
		freq[i]=0;
	int j=0;
	for(int i=0;i<osservazioni;i++)
		{
			for(j=0;j<m;j++)
		if((tempi[i]>=(min+n*j)) && (tempi[i] < (min+n*(j+1))))
			freq[j]++;
		}
	cout << "Vuoi salvare i dati sulla frequenza? [s/N] ";
	char scelta;
	cin.get(scelta);
	cin.clear();
	string fileSalva;
	ofstream salva;
	switch(scelta) //scelta output: file, stdout o niente.
	{
		case 's':	cout << "Salva come: ";
				cin >> fileSalva;
				salva.open(fileSalva.c_str());
				for(int i=0;i<m;i++)
				salva << min+n*i << " " << freq[i] << endl;
				salva.close();
				cout << "Dati salvati con successo." << endl;
				break;
		default :
			cout << "Vuoi stamparli su schermo? [s/N] ";
			cin.get(scelta);
			switch(scelta)
			{
				case 's':
				for(int i=0;i<m;i++)
				cout << min+n*i << " " << freq[i] << endl;
				default : break;
			}
			break;
	}
	double med = media(tempi,osservazioni);
	double s = sigma(tempi,osservazioni);
	// calcola media aritmetica
	cout << "La media aritmetica \u00e8: " << med << endl;
	// errore quadratico medio
	cout << "L'errore quadratico medio \u00e8 " << s << endl;
	cout << "L'errore sulla media \u00e8 " << s/sqrt(osservazioni) << endl;
	int conta=0;
//scarta valori oltre  media-3sigma e media+3sigma
	for(int i=0;i<osservazioni;i++)
	{
		if(tempi[i]>= (med - 3*s) && tempi[i] <= (med + 3*s))
		conta++;
	}
	double *buoni = new double[conta];
	int k=0;
	for(int i=0;i<osservazioni;i++)
	{
		if(tempi[i] >= (med - 3*s) && tempi[i] <= (med + 3*s))
	{
		buoni[k]=tempi[i];
		k++;
	}
	}
		// calcola media aritmetica
	int scartati = osservazioni-conta;
	if (scartati==1) //singolare e plurale
		cout << "\u00c8 stato scartato un solo valore." << endl;
	else	cout << "Sono stati scartati " << scartati << "valori." << endl;
	med = media(buoni,conta);
	s = sigma(buoni,conta);
	cout << "La nuova media \u00e8 " << med << endl;
	// errore quadratico medio
	cout << "Il nuovo errore quadratico medio \u00e8 " << s << endl;
	cout << "L'errore sulla media \u00e8 " << s/sqrt(conta) << endl;	
	return 0;
	}

int contarighe(string nomefile)
{
	ifstream input(nomefile.c_str());
	int righe,numeri;
	while (input >> numeri)
		righe++;
	input.close();
	return righe-1;
}

double trovamax(double array[], int l)
{
	double max=array[0];
	for(int i=0;i<l;i++)
	{
		if (max < array[i])
			max = array[i];
	}
	return max;
}

double trovamin(double array[], int l)
{
	double min=array[0];
	for(int i=0;i<l;i++)
	{
		if (min > array[i])
		min = array[i];
	}
	return min;
}

double media(double valori[], int l)
{
	double somma=0;
	for(int i=0;i<l;i++)
		somma+=valori[i];
	double xm = somma / double(l);
	return xm;
}

double sigma(double valori[], int l)
{
	double somma=0;
	for(int i=0;i<l;i++)
	somma+=(valori[i]-media(valori,l))*(valori[i]-media(valori,l));
	double si = sqrt(somma/double(l));
	return si;
}

